% convert the lpp into standard form 
% max z= 2x1-3x2+6x3
%   st x1-3x3>=4
%      2x1-8x2+3x3<=4
%      -x1-x2<=7
%      x1,x2,x3>=0
format short
clc
clear all
%% phase 1 : input the parameter 
C =[2 -3 6];  % cost of lpp
A = [1 0 -3; 2 -8 3;-1 -1 0];  % constraints coefficient
B = [4;4;7]; %RHS of the constraints
%% phase 2: identify <= or >= types constraints 
Ineqsign =[1 0 0]; % 0 for <= sign; 1 for >= sign.
%% phase 3: (imp) introducve the slack and surplus variable
s = eye(size(A,1)); %eye identity matrix %to generate identity matrix 
index = find(Ineqsign==1);
s(index,:)=-s(index,:);
%% phase 4: write the standard form
%express the objective function 
objfns = array2table(C); %for representing the objective function
objfns.Properties.VariableNames(1:size(C,2))={'x_1','x_2','x_3'} ;
%representation of constraints
Mat = [A s B];
const = array2table(Mat);
const.Properties.VariableNames(1:size(Mat,2))={'x_1','x_2','x_3','s_1','s_2','s_3','B'};
objfns
const     
     