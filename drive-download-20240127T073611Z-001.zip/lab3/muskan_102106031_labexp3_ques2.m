% convert the lpp into standard form 
% max z= 3x1+5x2
%   st x1+2x2<=20
%      x1+x2<=15
%      x2>=6
%      x1,x2>=0
format short
clc
clear all
%% phase 1 : input the parameter 
C =[3 5];  % cost of lpp
A = [1 2;1 1;0 1];  % constraints coefficient
B = [20;15;6]; %RHS of the constraints
%% phase 2: identify <= or >= types constraints 
Ineqsign =[0 0 1]; % 0 for <= sign; 1 for >= sign.
%% phase 3: (imp) introducve the slack and surplus variable
s = eye(size(A,1)); %eye identity matrix %to generate identity matrix 
index = find(Ineqsign==1);
s(index,:)=-s(index,:);
%% phase 4: write the standard form
%express the objective function 
objfns = array2table(C); %for representing the objective function
objfns.Properties.VariableNames(1:size(C,2))={'x_1','x_2'} ;
%representation of constraints
Mat = [A s B];
const = array2table(Mat);
const.Properties.VariableNames(1:size(Mat,2))={'x_1','x_2','s_1','s_2','s_3','B'};
objfns
const     
     