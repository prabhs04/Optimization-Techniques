% convert the lpp into standard form 
% max z= x1-3x2+2x3
%   st 3x1-x2+2x3>=7
%      -2x1+4x2<=2
%      -4x1+3x2+8x3>=5
%      x1,x2,x3>=0
format short
clc
clear all
%% phase 1 : input the parameter 
C =[1 -3 2];  % cost of lpp
A = [3 -1 2; -2 4 0;-4 3 8];  % constraints coefficient
B = [7;2;5]; %RHS of the constraints
%% phase 2: identify <= or >= types constraints 
Ineqsign =[1- 0 1]; % 0 for <= sign; 1 for >= sign.
%% phase 3: (imp) introduce the slack and surplus variable
s = eye(size(A,1)); %eye identity matrix %to generate identity matrix 
index = find(Ineqsign==1);
s(index,:)=-s(index,:);
%% phase 4: write the standard form
%express the objective function 
objfns = array2table(C); %for representing the objective function
objfns.Properties.VariableNames(1:size(C,2))={'x_1','x_2','x_3'} ;
%representation of constraints
Mat = [A s B];
const = array2table(Mat);
const.Properties.VariableNames(1:size(Mat,2))={'x_1','x_2','x_3','s_1','s_2','s_3','B'};
objfns
const     
     