%Find optimal basic feasible solution
% Max Z x1+x2+x3
% s.t. x1+x2+s1=1
%      -x2+x3+s2=0    
%      x1,x2,x3,s1,s2>=0
format short
clc
clear all
%% Phase 1: Input the parameter
C = [1 1 1 0 0];
A = [ 1 1 0 1 0; 0 -1 1 0 1];
B = [1; 0];
%% Phase 2: Number of constraints and variables
n = size(A,2); %no. of variables
m = size(A,1); %no. of constraints
%% Phase 3: Compute ncm of atmost bfs
nab = nchoosek(n,m); %total no. of atmost basic solution
t = nchoosek(1:n,m); %pair of basic solutiom
%% Phase 4: Construct the basic solution
sol = []; %default solution is zero
flag = 1;
degeneracy = [];
if n>m
    for i=1:nab
        y=zeros(n,1);
        x=A(:,t(i,:))\B;
        %Check the feasibilty condition
        if all(x>=0 & x~=inf & x~=-inf)
            y(t(i,:))=x;
            %Check degeneracy
            basic_var = y(t(i,:));
            for j = 1:size(basic_var)
                if basic_var(j)==0
                    degenerate = 1; %1 = Degenerate
                    break
                else
                    degenerate = 0; %0 = Non-Degenerate
                end
            end
            degeneracy(flag)=degenerate;
            flag=flag+1;
            sol = [sol y];
        end
    end
else
    error('Equation is larger than variable.')
end
sol
degeneracy
%% Phase 5: Compute the objective function and find optimal solution
Z = C*sol;
[Zmax Zind] = max(Z);
bfs = sol(:,Zind);
display('1 = Degenerate; 0 = Non-Degenerate')
Optimal_val = [bfs' Zmax degeneracy(Zind)];
Optimal_bfs = array2table(Optimal_val);
Optimal_bfs.Properties.VariableNames(1:size(Optimal_bfs,2))={'x_1','x_2','x3','s_1','s_2','Z','Degeneracy'};
Optimal_bfs