%Find optimal basic feasible solution
% Max -x1+2x2-x3
% s.t. x1+s1=4
%      x2+s2=4
%     -x1+x2+s3=6
%     -x1+2x3+s4=4
%      x1,x2,x3>=0
format short
clc
clear all
%% Phase 1:Input the parameter 
C=[-1 2 -1 0 0 0 0]; %Cost of LPP
A=[1 0 0 1 0 0 0;0 1 0 0 1 0 0;-1 1 0 0 0 1 0;-1 0 2 0 0 0 1]; %constraints coefficient
B=[4;4;6;4]; %RHS of constraints
%% Phase 2:No. of constraints and variable
m=size(A,1); %No. of constraints
n=size(A,2); %No. of variables
%% Phase3:Compute ncm of atmost bfs
nab=nchoosek(n,m); %total number of tamost basic sol
t=nchoosek(1:n,m); %pair of basic solution
%% Phase4:Construct the basic solution
sol=[];%default solution is zero
if n>=m
    for i=1:nab
        y=zeros(n,1);
        x=A(:,t(i,:))\B;
        %Check the feasibility condition
        if all(x>=0 & x~=inf & x~=-inf)
            y(t(i,:))=x;
            sol=[sol y];
        end
    end
else
    error('Equation is larger than variable')
end
sol
%% Phase 5: Compute the objective function and find optimal sol
Z=C*sol;
[Zmax Zind]=max(Z);
bfs=sol(:,Zind);
optimal_value=[bfs' Zmax];
optimal_bfs=array2table(optimal_value);
optimal_bfs.Properties.VariableNames(1:size(optimal_bfs,2))={'x_1','x_2','x_3','s_1','s_2','s_3','s_4','z'}