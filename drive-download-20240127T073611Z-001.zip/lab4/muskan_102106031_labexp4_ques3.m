%Find optimal basic feasible solution
% Min  5x2-2x1
% s.t. 2x1+5x2+s1=8
%      x1+2x2+s2=2
%      x1,x2>=0
format short
clc
clear all
%% Phase 1:Input the parameter 
C=[-2 5 0 0]; %Cost of LPP
A=[2 5 1 0;1 1 0 1]; %constraints coefficient
B=[8;2]; %RHS of constraints
%% Phase 2:No. of constraints and variable
m=size(A,1); %No. of constraints
n=size(A,2); %No. of variables
%% Phase3:Compute ncm of atmost bfs
nab=nchoosek(n,m); %total number of tamost basic sol
t=nchoosek(1:n,m); %pair of basic solution
%% Phase4:Construct the basic solution
sol=[];%default solution is zero
if n>=m
    for i=1:nab
        y=zeros(n,1);
        x=A(:,t(i,:))\B;
        %Check the feasibility condition
        if all(x>=0 & x~=inf & x~=-inf)
            y(t(i,:))=x;
            sol=[sol y];
        end
    end
else
    error('Equation is larger than variable')
end
sol
%% Phase 5: Compute the objective function and find optimal sol
Z=C*sol;
[Zmin Zind]=min(Z);
bfs=sol(:,Zind);
optimal_value=[bfs' Zmin];
optimal_bfs=array2table(optimal_value);
optimal_bfs.Properties.VariableNames(1:size(optimal_bfs,2))={'x_1','x_2','s_1','s_2','z'}