%basic feasible soln 
%max 2x1+3x2+4x3+7x4
%s.t. 2x1+3x2-x3+x4=8
%     x1-2x2+6x3-7x4=-3
%   xi>=0

format short
clc
clear all

%% phase1:  input the parameter
C = [2 3 4 7]; % cost of lpp
A =[2 3 -1 4;1 -2 6 -7]; % constraints coeff
B=[8;-3]; %rhs of constraints

%% phase 2: no of constraints and variables
m = size(A,1); %no of constraints
n = size(A,2); %no of variables

%% phase 3: compute ncm of atmost bfs
nab = nchoosek(n,m); %total no of basic soln
t = nchoosek(1:n,m); % pair of basic soln 

%% phase 4: construct the basic solution 
sol=[ ]; %default soln is zero
if n>=m
    for i = 1:nab
        y = zeros(n,1);
        x=A(:,t(i,:))\B; %diff values of x1 x2 x3 x4
        %check the feasibility of soln 
        if all(x>=0 & x~= inf &x ~=-inf)
            y(t(i,:))=x;
            sol = [sol y];
        end 
    end 
else
    error('equation is larger than variable')
end
% sol
 
%% phase 5: compute the objective function and find optimal soln 
Z = C*sol;
[Zmax Zind]=max(Z);
bfs = sol(:,Zind);
optimal_values =[bfs' Zmax];
optimal_bfs= array2table(optimal_values);
optimal_bfs.Properties.VariableNames(1:size(optimal_bfs,2))={'x_1','x_2','x_3','x_4','soln'}
