% Matlab code for Dual simplex method
% Slove the follwing LPP by Dual Simplex method
% Maximization Z=-2x1-x3
% Subject to x1+x2-x3>=5
%            x1-2x2+4x3>=8
%            x1,x2,x3>=0
% First we have all constraints must be of <= sign
%  -x1-x2+x3<=-5 (first constraints)
%   -x1+2x2-4x3<=-8
%% Phase-I Input Parameter
Variables={'x_1', 'x_2', 'x_3','s_1', 's_2','sol'}
Cost=[-2 0 -1 0 0 0];
Info=[-1 -1 1; -1 2 -4];
B=[-5; -8];
s=eye(size(Info,1));
A=[Info s B];
%% To find the starting BFS
BV=[];
for j=1:size(s,2)
    for i=1:size(A,2)
        if A(:,i)==s(:,j)
            BV=[BV i]
        end
    end
end
fprintf('Basic variables (BV)=')
disp(Variables(BV))
% To compute Z-row(Zj-Cj)
ZjCj=Cost(BV)*A-Cost;
% To print the table
ZCj=[ZjCj; A];
SimplexTable=array2table(ZCj);
SimplexTable.Properties.VariableNames(1:size(ZCj,2))=Variables
%% Dual simplex method starts
 Run=true
 while Run
sol=A(:,end)
if any(sol<0)
    fprintf('The current BFS is not feasible \n')
    %% Finding the leaving variable
    [Leaving_value, pvt_row]=min(sol)
    fprintf('Leaving row=%d\n',pvt_row)
    % Finding the entering variable
    Row=A(pvt_row,1:end-1)
    Zrow=ZjCj(:,1:end-1)
    for i=1:size(Row,2)
        if Row(i)<0
            ratio(i)=abs(Zrow(i)./Row(i))
        else
            ratio(i)=inf
        end
    end
    % To finding the minimum ratio
    [MinRatio, pvt_col]=min(ratio)
    fprintf('Entering variable is %d \n',pvt_col)
    BV(pvt_row)=pvt_col
    fprintf('Basic variable (BV)=')
    disp(Variables(BV))
    % pvt_key
    pvt_key=A(pvt_row,pvt_col)
    % Update the Table for next iteration
    A(pvt_row,:)=A(pvt_row,:)./pvt_key
    for i=1:size(A,1)
        if i~=pvt_row
            A(i,:)=A(i,:)-A(i,pvt_col).*A(pvt_row,:);
        end
        ZjCj=ZjCj-ZjCj(pvt_col).*A(pvt_row,:);
        % To print the table
        ZCj=[ZjCj;A];
        SimpTable=array2table(ZCj);
        SimpTable.Properties.VariableNames(1:size(ZCj,2))=Variables
    end
 else
     Run=false
     fprintf('The current BFS is feasible and optimal \n')
 end
 end
 %% Final Optimal Solution
 Final_BFS=zeros(1,size(A,2))
 Final_BFS(BV)=A(:,end)
 Final_BFS(end)=sum(Final_BFS.*Cost)
 OptimalBFS=array2table(Final_BFS)
 OptimalBFS.Properties.VariableNames(1:size(OptimalBFS,2))=Variables