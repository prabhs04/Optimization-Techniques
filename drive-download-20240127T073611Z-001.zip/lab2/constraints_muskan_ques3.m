function output = constraints_muskan_ques3(X)
% maximize z=5x2-x1
%st x1+x2 \leq 2
% 2x1+5x2\leq 8
%x1,x2\geq0
%% write first constraints
x1 = X(:,1);
x2 = X(:,2);
const1 = x1+x2-2; %<= sign
h1 = find(const1>0)
X(h1,:)=[];
%% write 2nd constraints
x1 = X(:,1);
x2 = X(:,2);
const2 = 2.*x1+5.*x2-8; %<= sign
h2 = find(const2>0);
X(h2,:)=[];
output = X;
end