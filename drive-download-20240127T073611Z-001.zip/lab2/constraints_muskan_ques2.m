function output = constraints_muskan_ques2(X)
% maximize z=5x1+8x2
%st x1+2x2 \leq 200
% x1+x2\leq 150
%x2 \leq 60
%x1,x2\geq0
%% write first constraints
x1 = X(:,1);
x2 = X(:,2);
const1 = x1+2.*x2-200; %<= sign
h1 = find(const1>0)
X(h1,:)=[];
%% write 2nd constraints
x1 = X(:,1);
x2 = X(:,2);
const2 = x1+x2-150; %<= sign
h2 = find(const2>0);
X(h2,:)=[];
output = X;
%% write 3rd constraint
x1 = X(:,1);
x2 = X(:,2);
const3 = x2-60; %<= sign
h2 = find(const3>0);
X(h2,:)=[];
output = X;
end