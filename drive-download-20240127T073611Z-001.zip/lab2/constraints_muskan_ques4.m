function output = constraints_muskan_ques4(X)
% maximize z=40x1+24x2
%st 20x1+50x2 \geq 480
% 80x1+50x2\geq 720
%x1,x2\geq0
%% write first constraints
x1 = X(:,1);
x2 = X(:,2);
const1 = 20.*x1+50.*x2-480; %>=sign
h1 = find(const1<0)
X(h1,:)=[];
%% write 2nd constraints
x1 = X(:,1);
x2 = X(:,2);
const2 = 80.*x1+50.*x2-720; %>= sign
h2 = find(const2<0);
X(h2,:)=[];
output = X;
end