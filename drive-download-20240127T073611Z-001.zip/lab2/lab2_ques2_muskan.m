% maximize z=5x1+8x2
%st x1+2x2 \leq 200
% x1+x2\leq 150
%x2 \leq 60
%x1,x2\geq0
%problem 2:
%% phase 1: input the parameter
clc
clear all
format short
C = [5 8];
A= [1 2;1 1;0 1];
B = [200;150;60];

%% phase 2: plotting the graph 
x1 = 0:1:max(B);
x31 =(B(1)-A(1,1).*x1)./A(1,2);
x32 = (B(2)-A(2,1).*x1)./A(2,2);
x33 = (B(3)-A(3,1).*x1)./A(3,2);
x31 = max(0,x31);
x32 = max(0,x32);
x33 = max(0,x33);
plot(x1,x31,'r',x1,x32,'m',x1,x33,'b','linewidth',2)
xlabel('value of x_1');
ylabel('value of x_2');
title('x_1 vs x_2');
legend('1x_1+2x_2\leq200','x_1+x_2\leq 150','x_2\leq 60');

%% phase 3: find the corner 
cx1=find(x1==0);%point with x1 axis
c1 = find(x31==0);%point with x2 axis
line1 =[x1(:,[c1 cx1]);x31(:,[c1 cx1])]';
c2 = find(x32==0);
line2 = [x1(:,[c2 cx1]);x32(:,[c2 cx1])]';
c3=find(x33==0);
Line3=[x1(:,[c3 cx1]); x33(:,[c3 cx1])]';
corpt= unique([line1 ; line2],'rows')

%% phse 4 : point of intersection 
MG = [0;0];
for i = 1:size(A,1)
    A1 =A(i,:);
    B1 =B(i,:);
    
for j = i+1:size(A,1)
    A2 = A(j,:);
    B2 = B(j,:);
    A4 = [A1;A2];
    B4=[B1;B2];
    X = A4\B4;
    MG = [MG ,X];
end
end
pt = MG';

%% phase 5: write all the corner points 
allpt = [pt;corpt];
points=unique(allpt,'rows');

%% phase 6: find all the feasible region
PT = constraints_muskan_ques2(points);
PT = unique(PT,'rows');

%% phase 7 : compute the objective function 
for i = 1:size(PT,1)
    Fx(i,:)=sum(PT(i,:).*C);
end

vert_fns = [PT,Fx];

%% phase 8: find the optimal solution 
[fxval,index]= max(Fx);
optval = vert_fns(index,:);
optimal_bfs = array2table(optval);
optimal_bfs.Properties.VariableNames(1:size(optimal_bfs,2))={'x_1','x_2','optimal_solution'}