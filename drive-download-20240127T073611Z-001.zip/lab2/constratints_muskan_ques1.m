function output = constratints_muskan_ques1(X)
% maximize z=6x1+11x2
%st 2x1+x2 \leq 104
% x1+2x2\leq 76
%x1,x2\geq0
%% write first constraints
x1 = X(:,1);
x2 = X(:,2);
const1 = 2.*x1+x2-104; %<= sign
h1 = find(const1>0)
X(h1,:)=[];
%% write 2nd constraints
x1 = X(:,1);
x2 = X(:,2);
const2 = x1+2.*x2-76; %<= sign
h2 = find(const2>0);
X(h2,:)=[];
output = X;
end