clc
clear all
format short
%% solve the lpp using big m
% maximise z = 3x1+2x2
% st     x1+x2 <= 2
%         x1+3x2<=3
%          x1 - x2 = 1
%          x1,x2 >=0
%% phase : - 1 information phase
variables = {'x_1','x_2','s_1','s_2','A_3','soln'};
M = 1000;
Cost = [3 2 0 0 -M 0]; % cost of lpp
A = [1 1 1 0 0 2 ; 1 3 0 1 0 3; 1 -1 0 0 1 1]; %constraints
s = eye(size(A,1));
%% to find the starting BFS
BV =[]
for j = 1:size(s,2)
    for i = 1:size(A,2)
        if A(:,i) == s(:,j)
            BV = [BV i]
        end 
    end 
end 
%% simplex method starts 
ZjCj=Cost(BV)*A-Cost;
% To print the table 
ZCj=[ZjCj; A];
Simplextable=array2table(ZCj)
Simplextable.Properties.VariableNames(1:size(ZCj,2))=variables
%% Simplex method Starts
 Run=true;
 while Run
    ZC=ZjCj(:,1:end-1)
    if any(ZC<0) % To check negative value
        fprintf('The current BFS is not optimal \n')
        fprintf('The next Iteration required \n')
        % To find the entering variable 
        [Entval, pvt_col]=min(ZC);
        fprintf('Entering column is %d \n',pvt_col)
        % To find leaving variable
        sol=A(:,end)
        Column=A(:,pvt_col)
        if all(Column<=0)
            fprintf('LPP has unbounded solution')
        else
            % To check minimum ratio with positve enteries
            for i=1:size(Column,1)
                if Column(i)>0
                    ratio(i)=sol(i)./Column(i)
                else
                    ratio(i)=inf
                end
            end
% To find the minimum ratio
[MinRatio, pvt_row]=min(ratio)
fprintf('Leaving row is %d \n',pvt_row)
        end
        BV(pvt_row)=pvt_col
        % pvt_key
        pvt_key=A(pvt_row,pvt_col);
        %% Update the table for next iteration
        A(pvt_row,:)=A(pvt_row,:)./pvt_key;
        for i=1:size(A,1)
            if i~=pvt_row
                A(i,:)=A(i,:)-A(i,pvt_col).*A(pvt_row,:);
            end
        end
            ZjCj=ZjCj-ZjCj(pvt_col).*A(pvt_row,:);
            % To print the table
            ZCj=[ZjCj;A];
            SimpTable=array2table(ZCj);
            SimpTable.Properties.VariableNames(1:size(ZCj,2))=variables
 else
     Run=false;
     fprintf('==== ***** =======')
     fprintf('The current BFS is optimal and optimality is reached \n')
    end
 end
 BFS=zeros(1,size(A,2))
 BFS(BV)=A(:,end)
 BFS(end)=sum(BFS.*Cost)
 currentBFS=array2table(BFS)
 currentBFS.Properties.VariableNames(1:size(currentBFS,2))=variables