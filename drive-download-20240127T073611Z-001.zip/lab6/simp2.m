function[BFS,A]=simp2(A,BV,Cost,variables)
ZjCj=Cost(BV)*A-Cost;
Run= true;
while Run
    ZCj=ZjCj(1:end-1);
    if any(ZCj<0)
        fprintf('The Current BFS is not optimal')
        [ent_col,pvt_col]=min(ZCj);
        fprintf('Entering Col = %d \n',pvt_col);
        Sol=A(:,end);
        Column=A(:,pvt_col);
        if Column<=0
            error('The LPP is unbounded');
        else
            for i=1:size(A,1)
                if Column(i)>0
                    ratio(i)=Sol(i)./Column(i);
                else
                    ratio(i)=inf;
                end
            end
            [MinRatio,pvt_row]=min(ratio);
            fprintf('Leaving Row=%d \n',pvt_row)
        end
        BV(pvt_row)=pvt_col;
        pvt_key=A(pvt_row,pvt_col);
        A(pvt_row,:)=A(pvt_row,:)./pvt_key;
        for i=1:size(A,1)
            if i~=pvt_row
                A(i,:)=A(i,:)-A(i,pvt_col).*A(pvt_row,:);
            end
        end
        ZjCj=ZjCj-ZjCj(pvt_col).*A(pvt_row,:)
        ZCj=[ZjCj;A];
        Table=array2table(ZCj);
        Table.Properties.VariableNames(1:size(ZCj,2))=variables
        BFS(BV)=A(:,end);
    else
        Run=false;
        fprintf('Current BFS is optimal\n')
        fprintf('********** PHASE 1 END **********')
        BFS=BV;
    end
end
end