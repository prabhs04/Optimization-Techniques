clc
clear all
variables={'x_1','x_2','x_3','a_1','a_2','sol'};
Ovariables={'x_1','x_2','x_3','sol'};
OrigC=[-1 2 3 -1 -1 0];
Info=[-2 1 3 1 0 2;2 3 4 0 1 1];
BV=[4 5];
%% Phase 1 starts
fprintf('***** phase-1 *****')
Cost=[0 0 0 -1 -1 0];
A=Info;
StartBV=find(Cost<0);
[BFS A]=simp(A, BV, Cost, variables);
 %% Phase 2 starts
 fprintf('***** phase-2 *****')
 A(:,StartBV)=[]; %removing artificial variables by giving them empty value
 OrigC(:,StartBV)=[]; %removing artificial variable cost by giving them empty value
 [OptBFS, OptA]=simp(A,BFS,OrigC,Ovariables);
 Final_BFS=zeros(1,size(A,2));
 Final_BFS(OptBFS)=OptA(:,end);
 Final_BFS(end)=sum(Final_BFS.*OrigC);
 OptimalBFS=array2table(Final_BFS);
 OptimalBFS.Properties.VariableNames(1:size(OptimalBFS,2))=Ovariables
