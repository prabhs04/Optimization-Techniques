clc
clear all
% solve the lpp
%maximize  z = x1+2x2
% st  -x1+x2<=1
%     x1+x2<=2
%      x1,x2>=0

%% phase1: input the parameter 
Noofvariable = 2;
variables = {'x_1','x_2','s_1','s_2','soln'};
C=[1 2]; %cost of objective function
Abar=[-1 1;1 1]; %const coeff
B = [1 ; 2]; %rhs of the constraints 
s = eye(size(Abar,1));
A = [Abar s B];
cost = zeros(1,size(A,2));
cost(1:Noofvariable)=C;
%% Constraints BV
BV= Noofvariable+1:1:size(A,2)-1;
%% calculate Zj-Cj row 
ZjCj = cost(BV)*A-cost;
%% for printing table 
ZCj =[ZjCj ;A];
Simplextable=array2table(ZCj);
Simplextable.Properties.VariableNames(1:size(ZCj,2))={'x_1','x_2','s_1','s_2','soln'};
Run = true;
while Run 
    
if any(ZjCj<0) %check if any negative value is there 
    fprintf('The current BFS is not optimal \n')
    fprintf('The next iteration is required \n')
    disp('old basic variable (BV) =  ')
    disp(BV)
    %% for finding the entering variable 
    Zc = ZjCj(1:end-1);
    [EnterCol , pivot_col] =  min(Zc);
    fprintf('The most negative element in Zj-Cj Row is %d corresponting to column %d \n' ,EnterCol , pivot_col)
    fprintf('Entering variable is %d \n',pivot_col)
    %% for finding leaving variable 
    sol = A(: ,end);
    column = A(: , pivot_col);
    if all(column<=0)
        error('Lpp has unbounded . since all the enteries are <=0 in column %d\n',pivot_col)
    else 
        % to check minimum ratio for positive pvt column entries 
        for i = 1:size(column,1)
            if column (i)> 0 
                ratio(i) = sol(i)./column(i);
            else 
                ratio(i)= inf;
            end
        end
    end 
    disp('ratio=')
    disp(ratio)
else 
    disp('optimal solution is reached')
end
%% to find minimum ratio 
[minratio,pvt_row] = min(ratio)
fprintf('minimum ratio corresponding to pivot row is %d \n',pvt_row)
fprintf('leaving variable is %d \n ',BV(pvt_row))
BV(pvt_row)=pivot_col;
disp('new basic variable (BV) = ')
disp(BV)
%% pivot key (% very important )
pvt_key = A(pvt_row,pivot_col);
%% update table for next iteration
A(pvt_row,:)=A(pvt_row,:)./pvt_key;
for i=1:size(A,1)
    if i~= pvt_row
        A(i,:)=A(i,:)-A(i,pivot_col).*A(pvt_row,:);
    end 
    ZjCj =ZjCj-ZjCj(pivot_col).*A(pvt_row,:);
end
%for printing
ZCj = [ZjCj;A];
Table = array2table(ZCj);
Table.Properties.VariableNames(1:size(ZCj,2)) = variables

BFS = zeros(1,size(A,2));
BFS(BV)= A (:,end);
BFS(end) = sum(BFS.*cost);
current_BFS= array2table(BFS);
current_BFS.Properties.VariableNames(1:size(current_BFS,2))= variables
if any(ZjCj(1:end-1)<0)
    Run = true;
else
    Run = false;
end

end
fprintf('the current BFS is optimal and value is %d hence optimality is reached \n',BFS(end))