clc
clear all
format short
% Matlab code for Least Cost Method (LCM)
% Input information
%% Input Phase
Cost=[2 7 4;3 3 1;5 5 4;1 6 2]
A=[5 8 7 14]
B=[7 9 18]
%% To check unbalanced/balanced problem
if sum(A)==sum(B)
    fprintf('Given Transportation problem is balanced \n')
else
    fprintf('Given Transportation problem is unbalanced \n')
    if sum(A)<sum(B)
        Cost(end+1,:)=zeros(1,size(B,2))
        A(end+1)=sum(B)-sum(A)
    elseif sum(B)<sum(A)
    Cost(:,end+1)=zeros(1,size(A,2))
    B(end+1)=sum(A)-sum(B)
    end
end
ICost=Cost
X=zeros(size(Cost))
[m,n]=size(Cost)
BFS=m+n-1
%% Finding the cell(with minimum cost) for the allocations
for i=1:size(Cost,1)
    for j=1:size(Cost,2)
hh=min(Cost(:)) %finding minimum cost value
        [Row_index, Col_index]=find(hh==Cost) % finding point of minimum cost
        x11=min(A(Row_index),B(Col_index))
[Value,index]=max(x11) %Find max allocation
ii=Row_index(index)
jj=Col_index(index)
y11=min(A(ii),B(jj))
X(ii,jj)=y11
A(ii)=A(ii)-y11
B(jj)=B(jj)-y11
Cost(ii,jj)=inf
    end
end
%% Print the initial BFS
fprintf('Initial BFS \n')
IBFS=array2table(X)
disp(IBFS)
%% Check for Degenerate and Non Degenerate 
TotalBFS=length(nonzeros(X))
if TotalBFS==BFS
    fprintf('Initial BFS is Non-Degenerate \n')
else
        fprintf('Initial BFS is Degenerate \n')
end
%% Compute the Initial Transportation Cost
InitialCost=sum(sum(ICost.*X))
fprintf('Initial BFS Cost is = %d \n',InitialCost)